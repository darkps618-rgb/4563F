package gale.dash;

import net.minecraft.resources.Identifier;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

/** Shared constants. The mod itself is client-only, see GaleDashClient. */
public final class GaleDash {
	public static final String MOD_ID = "galedash";
	public static final Logger LOGGER = LoggerFactory.getLogger(MOD_ID);

	private GaleDash() {}

	public static Identifier id(String path) {
		return Identifier.fromNamespaceAndPath(MOD_ID, path);
	}
}
