package gale.dash.client;

import gale.dash.GaleDash;
import net.fabricmc.api.ClientModInitializer;
import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientTickEvents;
import net.minecraft.client.Minecraft;
import net.minecraft.client.player.LocalPlayer;
import net.minecraft.world.InteractionHand;
import net.minecraft.world.entity.player.Inventory;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.Items;

/**
 * While holding a wind charge:
 *  - Left click in the air while rising (not looking up)  -> DASH: swap to the dash slot,
 *    use the item, swap back to the wind charge.
 *  - Left click while looking up                          -> PEARL CATCH: swap to an ender pearl,
 *    throw it, swap back to the wind charge.
 */
public class GaleDashClient implements ClientModInitializer {

	// ---- Settings (edit these, then rebuild) ----
	/** Looking up past this pitch (degrees, negative = up) counts as "looking up". */
	private static final float LOOK_UP_PITCH = -30.0f;
	/** Minimum upward speed (blocks/tick) to count as "going up with the wind charge". */
	private static final double RISING_SPEED = 0.05;
	/** Hotbar slot (1-9) used for the dash. 0 = just use the wind charge in hand again. */
	private static final int DASH_SLOT = 0;
	/** Set false to disable either feature. */
	private static final boolean ENABLE_DASH = true;
	private static final boolean ENABLE_PEARL_CATCH = true;
	// ---------------------------------------------

	private enum Stage { IDLE, SWAP_BACK }

	private Stage stage = Stage.IDLE;
	private int returnSlot = 0;
	private boolean wasAttackDown = false;

	@Override
	public void onInitializeClient() {
		ClientTickEvents.END_CLIENT_TICK.register(this::tick);
		GaleDash.LOGGER.info("GaleDash loaded");
	}

	private void tick(Minecraft mc) {
		LocalPlayer player = mc.player;
		if (player == null || mc.gameMode == null) {
			stage = Stage.IDLE;
			wasAttackDown = false;
			return;
		}

		boolean attackDown = mc.options.keyAttack.isDown();
		boolean clicked = attackDown && !wasAttackDown;
		wasAttackDown = attackDown;

		Inventory inv = player.getInventory();

		// Step 2: go back to the wind charge the tick after the action.
		if (stage == Stage.SWAP_BACK) {
			inv.setSelectedSlot(returnSlot);
			stage = Stage.IDLE;
			return;
		}

		if (!clicked || mc.screen != null) return;
		if (!player.getMainHandItem().is(Items.WIND_CHARGE)) return;

		boolean lookingUp = player.getXRot() <= LOOK_UP_PITCH;

		if (lookingUp) {
			if (!ENABLE_PEARL_CATCH) return;
			int pearlSlot = findHotbarSlot(inv, Items.ENDER_PEARL);
			if (pearlSlot < 0) return;
			swapUseAndQueueReturn(mc, player, inv, pearlSlot);
		} else {
			if (!ENABLE_DASH) return;
			boolean rising = !player.onGround() && player.getDeltaMovement().y > RISING_SPEED;
			if (!rising) return;

			int target = inv.getSelectedSlot();
			if (DASH_SLOT >= 1 && DASH_SLOT <= 9 && !inv.getItem(DASH_SLOT - 1).isEmpty()) {
				target = DASH_SLOT - 1;
			}
			swapUseAndQueueReturn(mc, player, inv, target);
		}
	}

	private void swapUseAndQueueReturn(Minecraft mc, LocalPlayer player, Inventory inv, int targetSlot) {
		returnSlot = inv.getSelectedSlot();
		inv.setSelectedSlot(targetSlot);
		mc.gameMode.useItem(player, InteractionHand.MAIN_HAND);
		player.swing(InteractionHand.MAIN_HAND);
		stage = Stage.SWAP_BACK;
	}

	private static int findHotbarSlot(Inventory inv, Item item) {
		for (int i = 0; i < 9; i++) {
			if (inv.getItem(i).is(item)) return i;
		}
		return -1;
	}
}
